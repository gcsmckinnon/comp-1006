<!DOCTYPE html>
<html>

<head>
  <title>PHP Syntax</title>
</head>

<body>
  <header>
    <h1>PHP Syntax</h1>
  </header>

  <section>
    <h2>PHP Tags (block & inline) & Commenting</h2>

    <!-- Block Tags -->
  </section>

  <section>
    <h2>Variables & Data Types</h2>
  </section>

  <section>
    <h2>Printing to the Screen (block & inline), Quotes, Concatenation & Interpolation</h2>
  </section>

  <section>
    <h2>Decision Structure</h2>
  </section>

  <section>
    <h2>Arrays & Hashes</h2>
  </section>

  <section>
    <h2>Repetition Structures</h2>
  </section>

  <section>
    <h2>Functions</h2>
  </section>

  <section>
    <h2>Common PHP Functions</h2>
  </section>

  <section>
    <h2>Objects (structs)</h2>
  </section>

  <section>
    <h2>Introducing Classes</h2>
  </section>
</body>

</html>